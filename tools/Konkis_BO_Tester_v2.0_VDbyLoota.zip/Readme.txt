Use EURUSDbo, 2016 Jan - Dec and 5M timeframe when you have selected the Robot
The load the setfile
Run in Visual Mode, minimize Metatrader it runs faster then
Et Voila, 66% and trippled account.