    __  ___     __        ____  _                        ____        __  _                                      
   /  |/  /__  / /_____ _/ __ )(_)___  ____ ________  __/ __ \____  / /_(_)___  ____  _____ _________  ____ ___ 
  / /|_/ / _ \/ __/ __ `/ __  / / __ \/ __ `/ ___/ / / / / / / __ \/ __/ / __ \/ __ \/ ___// ___/ __ \/ __ `__ \
 / /  / /  __/ /_/ /_/ / /_/ / / / / / /_/ / /  / /_/ / /_/ / /_/ / /_/ / /_/ / / / (__  )/ /__/ /_/ / / / / / /
/_/  /_/\___/\__/\__,_/_____/_/_/ /_/\__,_/_/   \__, /\____/ .___/\__/_/\____/_/ /_/____(_)___/\____/_/ /_/ /_/ 
                                               /____/     /_/                                                   

This indicator is offered for free by �MetaBinaryOptions.com under the GNU General Public License.
Please give credits to the authors if you plan to modify and redistribute the source code.

To install:
 1- Download and install Metatrader 4 from www.Metatrader4.com
 2- Open Metatrader and create a free demo account to get a live charts.
 3- Click Tools > Options > Expert Advisors > Check "Allow DLL Imports"
 4- Click Files > Open Data Folder > MQL4 > Indicators.
 5- Place the indicator (.ex4 file) in the Indicators folder.
 6- Restart Metatrader. The indicator will appear in your Navigator on the left. Drag it to a chart to run it.
 
Visit MetaBinaryOptions.com for more free indicators, strategies, reviews, and so much more!
